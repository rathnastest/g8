(function () {
  'use strict';
  var STORAGE_KEY = "gala:appearance:color-mode:v1";
  var RESOLVED_ATTRIBUTE = "data-gala-resolved-color-mode";
  var SELECTION_ATTRIBUTE = "data-gala-color-mode-selection";
  var SELECT_ID = "gala-appearance-color-mode";
  var MODE_LIGHT = "light";
  var MODE_DARK = "dark";
  var MODE_SYSTEM = "system";

  function isKnownMode(value) {
    return value === MODE_LIGHT || value === MODE_DARK || value === MODE_SYSTEM;
  }

  function readStoredSelection() {
    try {
      var value = window.localStorage.getItem(STORAGE_KEY);
      if (isKnownMode(value)) {
        return value;
      }
    } catch (error) {
      // Storage blocked (private mode, disabled site data, quota): the
      // session stays usable and this load falls back to MODE_SYSTEM below.
    }
    return MODE_SYSTEM;
  }

  function writeStoredSelection(mode) {
    try {
      window.localStorage.setItem(STORAGE_KEY, mode);
    } catch (error) {
      // Storage blocked: the selection simply does not persist past this
      // load; the visible page state this call site also applies still
      // updates normally.
    }
  }

  function systemPrefersDark() {
    try {
      return !!(
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches
      );
    } catch (error) {
      return false;
    }
  }

  function resolveMode(selection) {
    if (selection === MODE_LIGHT || selection === MODE_DARK) {
      return selection;
    }
    return systemPrefersDark() ? MODE_DARK : MODE_LIGHT;
  }

  function applySelection(selection) {
    var root = document.documentElement;
    root.setAttribute(SELECTION_ATTRIBUTE, selection);
    root.setAttribute(RESOLVED_ATTRIBUTE, resolveMode(selection));
  }

  // Phase 1 (synchronous, pre-paint): resolve and apply immediately.
  applySelection(readStoredSelection());

  // Live system-preference changes, only while the reader's own selection is
  // still exactly "system" (an explicit light/dark choice is never
  // overridden by a later system change).
  if (window.matchMedia) {
    try {
      var media = window.matchMedia('(prefers-color-scheme: dark)');
      var onSystemChange = function () {
        if (readStoredSelection() === MODE_SYSTEM) {
          applySelection(MODE_SYSTEM);
        }
      };
      if (typeof media.addEventListener === 'function') {
        media.addEventListener('change', onSystemChange);
      } else if (typeof media.addListener === 'function') {
        media.addListener(onSystemChange);
      }
    } catch (error) {
      // No live system-change subscription available: the resolved mode
      // this load already applied simply stays static until next load.
    }
  }

  // Phase 2 (deferred): wire the server-rendered control once it exists.
  document.addEventListener('DOMContentLoaded', function () {
    var select = document.getElementById(SELECT_ID);
    if (!select) return;
    select.value = readStoredSelection();
    select.addEventListener('change', function () {
      var next = select.value;
      if (!isKnownMode(next)) return;
      writeStoredSelection(next);
      applySelection(next);
    });
  });
})();
